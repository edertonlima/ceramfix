	
	<footer class="footer">
		<div class="container">
			<div class="row">
				<a href="#" class="social" target="_blank" title="facebook"><i class="fa fa-facebook"></i></a>
				<a href="#" class="social" target="_blank" title="twitter"><i class="fa fa-twitter"></i></a>
				<a href="#" class="di20"><img src="assets/images/logo_di20.png" alt="di20 DESENV." /></a>
			</div>
		</div>

		<a href="#" class="seta" rel="body"><i class="fa fa-angle-up" aria-hidden="true"></i></a>
	</footer>

</body>
</html>